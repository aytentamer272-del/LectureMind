# LectureMind AI - architecture
Kotlin + Compose + Material3 + Room (single module, MVVM).
Packages: ui/ (screens, theme), data/ (Room), audio/ (AudioRecord->WAV, import decode), stt/ (Vosk), ai/ (LlmProvider), export/ (PDF, DOCX).
