package com.lecturemind.ai.export

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object Exporter {
    private fun chunks(s: String): List<String> {
        if (s.length <= 700) return listOf(s)
        val r = mutableListOf<String>()
        var cur = StringBuilder()
        for (w in s.split(" ")) {
            if (cur.length + w.length > 700) { r.add(cur.toString()); cur = StringBuilder() }
            cur.append(w).append(' ')
        }
        if (cur.isNotEmpty()) r.add(cur.toString())
        return r
    }

    fun pdf(title: String, body: String, out: OutputStream) {
        val doc = PdfDocument()
        val w = 595; val h = 842; val m = 40
        val normal = TextPaint().apply { textSize = 12f; color = Color.BLACK; isAntiAlias = true }
        val big = TextPaint().apply { textSize = 20f; color = Color.BLACK; isAntiAlias = true; typeface = Typeface.DEFAULT_BOLD }
        var no = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, no).create())
        var y = m.toFloat()
        val blocks = mutableListOf<Pair<String, TextPaint>>(Pair(title, big))
        body.split("\n").forEach { line -> chunks(line.ifBlank { " " }).forEach { blocks.add(Pair(it, normal)) } }
        for ((text, paint) in blocks) {
            val l = StaticLayout.Builder.obtain(text, 0, text.length, paint, w - 2 * m)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL).build()
            if (y + l.height > h - m) {
                doc.finishPage(page)
                no++
                page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, no).create())
                y = m.toFloat()
            }
            val c = page.canvas
            c.save(); c.translate(m.toFloat(), y); l.draw(c); c.restore()
            y += l.height + 6
        }
        doc.finishPage(page)
        doc.writeTo(out)
        doc.close()
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    private fun rtl(s: String) = s.any { it in '\u0600'..'\u06FF' }

    private fun para(text: String, bold: Boolean, size: Int): String {
        val r = rtl(text)
        return "<w:p><w:pPr>" + (if (r) "<w:bidi/>" else "") + "</w:pPr><w:r><w:rPr>" +
            (if (bold) "<w:b/>" else "") + "<w:sz w:val=\"$size\"/>" + (if (r) "<w:rtl/>" else "") +
            "</w:rPr><w:t xml:space=\"preserve\">" + esc(text) + "</w:t></w:r></w:p>"
    }

    fun docx(title: String, body: String, out: OutputStream) {
        val z = ZipOutputStream(out)
        fun put(n: String, c: String) { z.putNextEntry(ZipEntry(n)); z.write(c.toByteArray(Charsets.UTF_8)); z.closeEntry() }
        val head = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
        put("[Content_Types].xml", head + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>")
        put("_rels/.rels", head + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>")
        val sb = StringBuilder()
        sb.append(para(title, true, 36))
        body.split("\n").forEach { sb.append(para(it, false, 24)) }
        put("word/document.xml", head + "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>" +
            sb.toString() + "</w:body></w:document>")
        z.finish()
        z.flush()
    }
}
