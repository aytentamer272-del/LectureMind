package com.lecturemind.ai.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Navy = Color(0xFF17152B)
val Purple = Color(0xFF7665E8)
val Lavender = Color(0xFFA99BFF)
val LightBg = Color(0xFFF5F4FA)
val DarkSurface = Color(0xFF242238)
val Success = Color(0xFF36BFA0)

private val Light = lightColorScheme(
    primary = Purple, secondary = Lavender, tertiary = Success,
    background = LightBg, surface = Color.White, onPrimary = Color.White
)
private val Dark = darkColorScheme(
    primary = Lavender, secondary = Purple, tertiary = Success,
    background = Navy, surface = DarkSurface, onPrimary = Navy
)

@Composable
fun LectureMindTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) Dark else Light, content = content)
}
