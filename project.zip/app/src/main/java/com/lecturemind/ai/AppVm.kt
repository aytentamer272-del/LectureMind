package com.lecturemind.ai

import android.app.Application
import android.net.Uri
import android.widget.Toast
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.lecturemind.ai.ai.Engine
import com.lecturemind.ai.audio.WavRecorder
import com.lecturemind.ai.audio.importAudio
import com.lecturemind.ai.data.*
import com.lecturemind.ai.export.Exporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ChatLine(val user: Boolean, val text: String)

class AppVm(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()
    val subjects = dao.subjects().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val lectures = dao.lectures().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val cards = dao.cards().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    var subjectFilter by mutableStateOf<Long?>(null)
    val chats = mutableStateMapOf<Long, List<ChatLine>>()

    fun lecture(id: Long) = dao.lecture(id)
    fun cardsOf(id: Long) = dao.cardsOf(id)
    fun questionsOf(id: Long) = dao.questionsOf(id)

    // ---- recording ----
    var recState by mutableIntStateOf(0) // 0 idle, 1 recording, 2 paused
    var recMs by mutableLongStateOf(0L)
    private var recorder: WavRecorder? = null
    private var recFile: File? = null

    fun startRec() {
        val f = File(getApplication<Application>().filesDir, "rec_${System.currentTimeMillis()}.wav")
        recFile = f
        recorder = WavRecorder(f).also { it.start() }
        recState = 1
    }
    fun pauseRec() { recorder?.paused = true; recState = 2 }
    fun resumeRec() { recorder?.paused = false; recState = 1 }
    fun tick() { recMs = recorder?.durationMs ?: 0L }
    fun stopRec(title: String) {
        val r = recorder ?: return
        r.stop()
        val f = recFile ?: return
        val dur = r.durationMs
        recorder = null
        recState = 0
        recMs = 0
        val t = title.ifBlank { "Lecture " + SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()) }
        viewModelScope.launch { dao.insertLecture(Lecture(title = t, audioPath = f.path, durationMs = dur)) }
    }

    fun importAudioFile(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val (path, dur) = importAudio(getApplication<Application>(), uri)
                dao.insertLecture(Lecture(title = "Imported " + SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()), audioPath = path, durationMs = dur))
                toast("Imported")
            } catch (e: Exception) { toast("Import failed") }
        }
    }

    // ---- organization ----
    fun addSubject(name: String) { if (name.isNotBlank()) viewModelScope.launch { dao.insertSubject(Subject(name = name.trim())) } }
    fun deleteSubject(s: Subject) { viewModelScope.launch { dao.detachSubject(s.id); dao.deleteSubject(s); if (subjectFilter == s.id) subjectFilter = null } }
    fun updateLecture(l: Lecture) { viewModelScope.launch { dao.updateLecture(l) } }
    fun deleteLecture(l: Lecture) {
        viewModelScope.launch(Dispatchers.IO) {
            l.audioPath?.let { File(it).delete() }
            dao.clearCards(l.id); dao.clearQuestions(l.id); dao.deleteLecture(l)
        }
    }

    // ---- study features ----
    fun generateNotes(l: Lecture) { viewModelScope.launch { dao.updateLecture(l.copy(summary = Engine.notes(l.transcript))) } }
    fun generateCards(l: Lecture) {
        viewModelScope.launch { dao.clearCards(l.id); dao.insertCards(Engine.flashcards(l.transcript, l.id)) }
    }
    fun generateQuiz(l: Lecture, diff: Int) {
        viewModelScope.launch { dao.clearQuestions(l.id); dao.insertQuestions(Engine.quiz(l.transcript, l.id, diff)) }
    }
    fun markCard(c: Flashcard, reviewed: Boolean) { viewModelScope.launch { dao.updateCard(c.copy(reviewed = reviewed)) } }
    fun ask(l: Lecture, q: String) {
        val old = chats[l.id] ?: emptyList()
        chats[l.id] = old + ChatLine(true, q) + ChatLine(false, Engine.answer(q, l.transcript))
    }

    // ---- export ----
    fun export(l: Lecture, kind: Int, pdf: Boolean, uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val body = when (kind) {
                    0 -> l.transcript
                    1 -> l.summary
                    2 -> dao.questionsOnce(l.id).mapIndexed { i, q ->
                        "${i + 1}. [${q.type}] ${q.question}\n" +
                            (if (q.options.isNotBlank()) q.options.split("|").joinToString("\n") { "   - $it" } + "\n" else "") +
                            "Answer: ${q.answer}\n${q.explanation}\n"
                    }.joinToString("\n")
                    else -> dao.cardsOnce(l.id).joinToString("\n\n") { "Q: ${it.question}\nA: ${it.answer}" }
                }
                if (body.isBlank()) { toast("Nothing to export yet"); return@launch }
                val ctx = getApplication<Application>()
                ctx.contentResolver.openOutputStream(uri)!!.use {
                    if (pdf) Exporter.pdf(l.title, body, it) else Exporter.docx(l.title, body, it)
                }
                toast("Exported")
            } catch (e: Exception) { toast("Export failed") }
        }
    }

    fun wipeAll() {
        viewModelScope.launch(Dispatchers.IO) {
            dao.clearAllCards(); dao.clearAllQuestions(); dao.clearLectures(); dao.clearSubjects()
            getApplication<Application>().filesDir.listFiles()?.forEach { if (it.extension == "wav" || it.extension == "audio") it.delete() }
            chats.clear()
        }
    }

    private suspend fun toast(m: String) = withContext(Dispatchers.Main) {
        Toast.makeText(getApplication<Application>(), m, Toast.LENGTH_SHORT).show()
    }
}
