package com.lecturemind.ai.audio

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaMetadataRetriever
import android.media.MediaRecorder
import android.net.Uri
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Records 16 kHz mono 16-bit PCM into a WAV file. Pause/resume supported. */
class WavRecorder(private val file: File) {
    @Volatile var paused = false
    @Volatile private var running = false
    @Volatile private var samples = 0L
    private var thread: Thread? = null
    val durationMs: Long get() = samples * 1000 / RATE

    @SuppressLint("MissingPermission")
    fun start() {
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(
            MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 8192)
        )
        running = true
        rec.startRecording()
        thread = Thread {
            val out = RandomAccessFile(file, "rw")
            out.setLength(0)
            out.write(ByteArray(44))
            val buf = ByteArray(4096)
            var total = 0L
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                if (n > 0 && !paused) {
                    out.write(buf, 0, n)
                    total += n
                    samples = total / 2
                }
            }
            rec.stop()
            rec.release()
            val bb = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            bb.put("RIFF".toByteArray()); bb.putInt((36 + total).toInt())
            bb.put("WAVE".toByteArray()); bb.put("fmt ".toByteArray())
            bb.putInt(16); bb.putShort(1); bb.putShort(1)
            bb.putInt(RATE); bb.putInt(RATE * 2); bb.putShort(2); bb.putShort(16)
            bb.put("data".toByteArray()); bb.putInt(total.toInt())
            out.seek(0)
            out.write(bb.array())
            out.close()
        }.also { it.start() }
    }

    fun stop() {
        running = false
        thread?.join()
    }

    companion object { const val RATE = 16000 }
}

/** Copies a picked audio file into app storage. Returns (path, durationMs). */
fun importAudio(ctx: Context, uri: Uri): Pair<String, Long> {
    val f = File(ctx.filesDir, "import_${System.currentTimeMillis()}.audio")
    ctx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
    var dur = 0L
    try {
        val r = MediaMetadataRetriever()
        r.setDataSource(f.path)
        dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        r.release()
    } catch (e: Exception) { }
    return Pair(f.path, dur)
}
