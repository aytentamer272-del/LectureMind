package com.lecturemind.ai.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity
data class Subject(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String)

@Entity
data class Lecture(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val subjectId: Long? = null,
    val audioPath: String? = null,
    val durationMs: Long = 0,
    val transcript: String = "",
    val summary: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity
data class Flashcard(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val lectureId: Long,
    val question: String,
    val answer: String,
    val reviewed: Boolean = false
)

@Entity
data class QuizQuestion(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val lectureId: Long,
    val type: String,
    val question: String,
    val options: String = "",
    val answer: String,
    val explanation: String = ""
)

@Dao
interface LmDao {
    @Query("SELECT * FROM Subject ORDER BY name") fun subjects(): Flow<List<Subject>>
    @Insert suspend fun insertSubject(s: Subject): Long
    @Delete suspend fun deleteSubject(s: Subject)
    @Query("UPDATE Lecture SET subjectId = NULL WHERE subjectId = :id") suspend fun detachSubject(id: Long)

    @Query("SELECT * FROM Lecture ORDER BY createdAt DESC") fun lectures(): Flow<List<Lecture>>
    @Query("SELECT * FROM Lecture WHERE id = :id") fun lecture(id: Long): Flow<Lecture?>
    @Query("SELECT * FROM Lecture") suspend fun lecturesOnce(): List<Lecture>
    @Insert suspend fun insertLecture(l: Lecture): Long
    @Update suspend fun updateLecture(l: Lecture)
    @Delete suspend fun deleteLecture(l: Lecture)
    @Query("DELETE FROM Lecture") suspend fun clearLectures()

    @Query("SELECT * FROM Flashcard ORDER BY id") fun cards(): Flow<List<Flashcard>>
    @Query("SELECT * FROM Flashcard WHERE lectureId = :id ORDER BY id") fun cardsOf(id: Long): Flow<List<Flashcard>>
    @Query("SELECT * FROM Flashcard WHERE lectureId = :id ORDER BY id") suspend fun cardsOnce(id: Long): List<Flashcard>
    @Insert suspend fun insertCards(c: List<Flashcard>)
    @Update suspend fun updateCard(c: Flashcard)
    @Query("DELETE FROM Flashcard WHERE lectureId = :id") suspend fun clearCards(id: Long)
    @Query("DELETE FROM Flashcard") suspend fun clearAllCards()

    @Query("SELECT * FROM QuizQuestion WHERE lectureId = :id ORDER BY id") fun questionsOf(id: Long): Flow<List<QuizQuestion>>
    @Query("SELECT * FROM QuizQuestion WHERE lectureId = :id ORDER BY id") suspend fun questionsOnce(id: Long): List<QuizQuestion>
    @Insert suspend fun insertQuestions(q: List<QuizQuestion>)
    @Query("DELETE FROM QuizQuestion WHERE lectureId = :id") suspend fun clearQuestions(id: Long)
    @Query("DELETE FROM QuizQuestion") suspend fun clearAllQuestions()
    @Query("DELETE FROM Subject") suspend fun clearSubjects()
}

@Database(entities = [Subject::class, Lecture::class, Flashcard::class, QuizQuestion::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): LmDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "lecturemind.db").build().also { inst = it }
        }
    }
}
