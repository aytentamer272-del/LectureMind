package com.lecturemind.ai.ai

import com.lecturemind.ai.data.Flashcard
import com.lecturemind.ai.data.QuizQuestion
import kotlin.math.sqrt

/**
 * Basic OFFLINE study engine (extractive, rule-based). It selects and rearranges sentences
 * from the lecture text; it does not understand or rewrite content like a large language model.
 */
object Engine {
    private val wordRe = Regex("[\\p{L}\\p{N}]+")
    private val stop = setOf(
        "the", "and", "that", "this", "with", "for", "are", "was", "were", "have", "has", "from", "they",
        "you", "your", "not", "but", "can", "will", "what", "which", "there", "their", "about", "into",
        "than", "then", "also", "when", "how", "why", "its", "been", "would", "could", "should", "these",
        "those", "such", "more", "most", "some", "any", "all", "one", "und", "der", "die", "das", "nicht",
        "mit", "von", "ein", "eine", "est", "les", "des", "une", "pour", "dans", "que", "qui", "pas", "plus",
        "من", "في", "على", "إلى", "عن", "هذا", "هذه", "ذلك", "التي", "الذي", "كان", "أن", "إن", "ما", "هو", "هي", "لا", "مع", "كل"
    )
    private val defRe = Regex("\\b(is a|is an|is the|refers to|means|defined as)\\b|يعني|تعرف|يعرف|هو |هي ", RegexOption.IGNORE_CASE)
    private val exRe = Regex("for example|for instance|e\\.g\\.|such as|مثال|مثلا|مثلاً", RegexOption.IGNORE_CASE)

    fun isArabic(s: String) = s.any { it in '\u0600'..'\u06FF' }
    fun words(s: String): List<String> = wordRe.findAll(s.lowercase()).map { it.value }.toList()

    fun sentences(t: String): List<String> =
        t.split(Regex("(?<=[.!?\u061F])\\s+|\\n+")).map { it.trim() }.filter { words(it).size >= 4 }

    fun keywords(t: String, n: Int): List<String> =
        words(t).filter { it.length > 3 && it !in stop && !it.all { c -> c.isDigit() } }
            .groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.take(n).map { it.key }

    fun top(t: String, n: Int): List<String> {
        val s = sentences(t)
        if (s.size <= n) return s
        val kw = keywords(t, 20).toSet()
        return s.withIndex()
            .map { (i, x) -> Triple(i, x, words(x).count { it in kw } / sqrt(words(x).size.toDouble())) }
            .sortedByDescending { it.third }.take(n).sortedBy { it.first }.map { it.second }
    }

    fun notes(t: String): String {
        if (sentences(t).isEmpty()) return ""
        val ar = isArabic(t)
        val sb = StringBuilder()
        sb.append(if (ar) "الملخص" else "Summary").append("\n")
        top(t, 5).forEach { sb.append(it).append("\n") }
        sb.append("\n").append(if (ar) "النقاط المهمة" else "Key points").append("\n")
        top(t, 8).forEach { sb.append("• ").append(it).append("\n") }
        val defs = sentences(t).filter { defRe.containsMatchIn(it) }.take(4)
        if (defs.isNotEmpty()) {
            sb.append("\n").append(if (ar) "تعريفات محتملة" else "Possible definitions").append("\n")
            defs.forEach { sb.append("• ").append(it).append("\n") }
        }
        val exs = sentences(t).filter { exRe.containsMatchIn(it) }.take(4)
        if (exs.isNotEmpty()) {
            sb.append("\n").append(if (ar) "أمثلة" else "Examples").append("\n")
            exs.forEach { sb.append("• ").append(it).append("\n") }
        }
        sb.append("\n").append(if (ar) "المصطلحات المهمة" else "Important terms").append("\n")
        sb.append(keywords(t, 10).joinToString(if (ar) "، " else ", "))
        return sb.toString().trim()
    }

    fun flashcards(t: String, lectureId: Long): List<Flashcard> {
        val kw = keywords(t, 30)
        val ar = isArabic(t)
        val out = mutableListOf<Flashcard>()
        for (s in top(t, 10)) {
            val k = kw.firstOrNull { s.contains(it, true) } ?: continue
            out.add(
                Flashcard(
                    lectureId = lectureId,
                    question = (if (ar) "أكمل: " else "Complete: ") + s.replace(k, "_____", true),
                    answer = k + "\n" + s
                )
            )
        }
        return out
    }

    fun quiz(t: String, lectureId: Long, diff: Int): List<QuizQuestion> {
        val kw = keywords(t, 30)
        val ar = isArabic(t)
        val yes = if (ar) "صح" else "True"
        val no = if (ar) "خطأ" else "False"
        val out = mutableListOf<QuizQuestion>()
        var i = 0
        for (s in top(t, 6 + 4 * diff)) {
            val k = kw.firstOrNull { s.contains(it, true) } ?: continue
            val blank = s.replace(k, "_____", true)
            when (i % 4) {
                0 -> {
                    val opts = (kw.filter { it != k }.shuffled().take(2 + diff) + k).shuffled()
                    out.add(QuizQuestion(lectureId = lectureId, type = "MCQ", question = blank,
                        options = opts.joinToString("|"), answer = k, explanation = s))
                }
                1 -> {
                    val d = kw.firstOrNull { it != k && !s.contains(it, true) }
                    val makeFalse = (i / 4) % 2 == 0 && d != null
                    val q = if (makeFalse) s.replace(k, d!!, true) else s
                    out.add(QuizQuestion(lectureId = lectureId, type = "TF", question = q,
                        options = "$yes|$no", answer = if (makeFalse) no else yes, explanation = s))
                }
                2 -> out.add(QuizQuestion(lectureId = lectureId, type = "FILL", question = blank, answer = k, explanation = s))
                else -> out.add(QuizQuestion(lectureId = lectureId, type = "SHORT",
                    question = (if (ar) "ماذا تقول المحاضرة عن: " else "What does the lecture say about: ") + k,
                    answer = s, explanation = s))
            }
            i++
        }
        return out
    }

    /** Answers only from lecture sentences; never invents content. */
    fun answer(q: String, t: String): String {
        val ar = isArabic(t) || isArabic(q)
        if (t.isBlank()) return if (ar) "لا يوجد نص لهذه المحاضرة بعد." else "This lecture has no transcript yet."
        if (Regex("summar|ملخص|لخص", RegexOption.IGNORE_CASE).containsMatchIn(q)) {
            return notes(t).ifBlank { if (ar) "النص قصير جدا." else "The transcript is too short." }
        }
        val qw = words(q).filter { it.length > 2 && it !in stop }.toSet()
        val hits = sentences(t).map { it to words(it).count { w -> w in qw } }
            .filter { it.second > 0 }.sortedByDescending { it.second }.take(3)
        if (hits.isEmpty()) return if (ar) "لا أجد الإجابة في محتوى هذه المحاضرة." else "I can't find this in the lecture content."
        return hits.joinToString("\n\n") { it.first }
    }
}
