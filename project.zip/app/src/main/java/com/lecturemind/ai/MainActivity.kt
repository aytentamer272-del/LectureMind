package com.lecturemind.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.StringRes
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.lecturemind.ai.ui.LectureMindTheme
import kotlinx.coroutines.launch

enum class Dest(@StringRes val title: Int) {
    Home(R.string.nav_home), Lectures(R.string.nav_lectures), Record(R.string.nav_record),
    Subjects(R.string.nav_subjects), Assistant(R.string.nav_assistant),
    Flashcards(R.string.nav_flashcards), Quizzes(R.string.nav_quizzes),
    Settings(R.string.nav_settings)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LectureMindTheme { AppRoot() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot() {
    var current by remember { mutableStateOf(Dest.Home) }
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet {
                Text(stringResource(R.string.app_name), style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(24.dp))
                Dest.values().forEach { d ->
                    NavigationDrawerItem(
                        label = { Text(stringResource(d.title)) },
                        selected = d == current,
                        onClick = { current = d; scope.launch { drawer.close() } },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                }
            }
        }
    ) {
        Scaffold(topBar = {
            TopAppBar(
                title = { Text(stringResource(current.title)) },
                navigationIcon = { TextButton(onClick = { scope.launch { drawer.open() } }) { Text("☰") } }
            )
        }) { pad ->
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                    Text(stringResource(R.string.tagline), style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(12.dp))
                    Text(stringResource(R.string.coming_soon))
                }
            }
        }
    }
}
