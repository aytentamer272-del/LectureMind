package com.lecturemind.ai

import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.annotation.StringRes
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lecturemind.ai.ui.*
import kotlinx.coroutines.launch
import java.util.Locale

enum class Dest(@StringRes val title: Int) {
    Home(R.string.nav_home), Lectures(R.string.nav_lectures), Record(R.string.nav_record),
    Subjects(R.string.nav_subjects), Assistant(R.string.nav_assistant),
    Flashcards(R.string.nav_flashcards), Quizzes(R.string.nav_quizzes),
    Settings(R.string.nav_settings)
}

class MainActivity : ComponentActivity() {
    override fun attachBaseContext(base: Context) {
        val lang = base.getSharedPreferences("s", 0).getString("lang", "") ?: ""
        if (lang.isEmpty()) {
            super.attachBaseContext(base)
        } else {
            val l = Locale(lang)
            Locale.setDefault(l)
            val c = Configuration(base.resources.configuration)
            c.setLocale(l)
            c.setLayoutDirection(l)
            super.attachBaseContext(base.createConfigurationContext(c))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("s", 0)
        setContent {
            var dark by remember { mutableIntStateOf(prefs.getInt("dark", 0)) }
            val isDark = when (dark) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
            LectureMindTheme(dark = isDark) {
                AppRoot(
                    dark = dark,
                    onDark = { dark = it; prefs.edit().putInt("dark", it).apply() },
                    lang = prefs.getString("lang", "") ?: "",
                    onLang = { prefs.edit().putString("lang", it).apply(); recreate() }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot(dark: Int, onDark: (Int) -> Unit, lang: String, onLang: (String) -> Unit) {
    val vm: AppVm = viewModel()
    var current by remember { mutableStateOf(Dest.Home) }
    var openId by remember { mutableStateOf<Long?>(null) }
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    BackHandler(enabled = openId != null) { openId = null }
    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet {
                Text(stringResource(R.string.app_name), style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(24.dp))
                Dest.values().forEach { d ->
                    NavigationDrawerItem(
                        label = { Text(stringResource(d.title)) },
                        selected = d == current && openId == null,
                        onClick = { current = d; openId = null; scope.launch { drawer.close() } },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                }
            }
        }
    ) {
        Scaffold(topBar = {
            TopAppBar(
                title = { Text(stringResource(current.title)) },
                navigationIcon = { TextButton(onClick = { scope.launch { drawer.open() } }) { Text("☰") } }
            )
        }) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                val id = openId
                if (id != null) {
                    LectureDetail(vm, id) { openId = null }
                } else {
                    when (current) {
                        Dest.Home -> HomeScreen(vm, { openId = it }, { current = it })
                        Dest.Lectures -> LecturesScreen(vm) { openId = it }
                        Dest.Record -> RecordScreen(vm)
                        Dest.Subjects -> SubjectsScreen(vm) { current = it }
                        Dest.Assistant -> AssistantScreen(vm)
                        Dest.Flashcards -> FlashcardsScreen(vm)
                        Dest.Quizzes -> QuizzesScreen(vm)
                        Dest.Settings -> SettingsScreen(vm, dark, onDark, lang, onLang)
                    }
                }
            }
        }
    }
}
