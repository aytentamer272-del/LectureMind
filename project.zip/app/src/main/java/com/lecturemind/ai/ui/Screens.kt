package com.lecturemind.ai.ui

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaPlayer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.lecturemind.ai.AppVm
import com.lecturemind.ai.Dest
import com.lecturemind.ai.R
import com.lecturemind.ai.data.*
import kotlinx.coroutines.delay
import java.text.DateFormat
import java.util.Date

@Composable
fun t(en: String, ar: String): String =
    if (LocalConfiguration.current.locales[0].language == "ar") ar else en

fun fmt(ms: Long): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }

@Composable
fun Stat(n: Int, label: String, m: Modifier) {
    Card(m) { Column(Modifier.padding(16.dp)) { Text("$n", style = MaterialTheme.typography.headlineMedium); Text(label) } }
}

@Composable
fun LectureRow(l: Lecture, subjects: List<Subject>, onOpen: (Long) -> Unit) {
    Card(onClick = { onOpen(l.id) }, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(l.title, style = MaterialTheme.typography.titleMedium)
            Text(
                listOfNotNull(subjects.find { it.id == l.subjectId }?.name, fmt(l.durationMs),
                    DateFormat.getDateInstance().format(Date(l.createdAt))).joinToString(" • "),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
fun HomeScreen(vm: AppVm, onOpen: (Long) -> Unit, onGo: (Dest) -> Unit) {
    val lectures by vm.lectures.collectAsState()
    val cards by vm.cards.collectAsState()
    val subjects by vm.subjects.collectAsState()
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text(stringResource(R.string.tagline), style = MaterialTheme.typography.titleMedium) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Stat(lectures.size, t("Lectures", "محاضرات"), Modifier.weight(1f))
                Stat(cards.size, t("Cards", "بطاقات"), Modifier.weight(1f))
            }
        }
        item { Button(onClick = { onGo(Dest.Record) }, modifier = Modifier.fillMaxWidth()) { Text(t("Start recording", "ابدأ التسجيل")) } }
        item { Text(t("Recent lectures", "آخر المحاضرات"), style = MaterialTheme.typography.titleSmall) }
        items(lectures.take(5), key = { it.id }) { LectureRow(it, subjects, onOpen) }
    }
}

@Composable
fun LecturesScreen(vm: AppVm, onOpen: (Long) -> Unit) {
    val lectures by vm.lectures.collectAsState()
    val subjects by vm.subjects.collectAsState()
    var q by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.importAudioFile(uri) }
    val filter = vm.subjectFilter
    val list = lectures.filter {
        (filter == null || it.subjectId == filter) &&
            (q.isBlank() || it.title.contains(q, true) || it.transcript.contains(q, true))
    }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), label = { Text(t("Search", "بحث")) }, singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { picker.launch(arrayOf("audio/*")) }) { Text(t("Import audio", "استيراد صوت")) }
            if (filter != null) {
                FilterChip(selected = true, onClick = { vm.subjectFilter = null },
                    label = { Text((subjects.find { it.id == filter }?.name ?: "") + "  ✕") })
            }
        }
        if (list.isEmpty()) Text(t("No lectures yet. Record or import one.", "لا توجد محاضرات. سجّل أو استورد محاضرة."))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list, key = { it.id }) { LectureRow(it, subjects, onOpen) }
        }
    }
}

@Composable
fun RecordScreen(vm: AppVm) {
    val ctx = LocalContext.current
    var title by remember { mutableStateOf("") }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) vm.startRec() }
    LaunchedEffect(vm.recState) { while (vm.recState != 0) { vm.tick(); delay(200) } }
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(
            when (vm.recState) { 1 -> t("Recording…", "جارٍ التسجيل…"); 2 -> t("Paused", "متوقف مؤقتا"); else -> t("Ready", "جاهز") },
            style = MaterialTheme.typography.titleMedium
        )
        Text(fmt(vm.recMs), style = MaterialTheme.typography.displayLarge)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), label = { Text(t("Lecture title", "عنوان المحاضرة")) }, singleLine = true)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            when (vm.recState) {
                0 -> Button(onClick = {
                    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) vm.startRec()
                    else perm.launch(Manifest.permission.RECORD_AUDIO)
                }) { Text(t("Start", "ابدأ")) }
                1 -> Button(onClick = { vm.pauseRec() }) { Text(t("Pause", "إيقاف مؤقت")) }
                else -> Button(onClick = { vm.resumeRec() }) { Text(t("Resume", "استئناف")) }
            }
            if (vm.recState != 0) OutlinedButton(onClick = { vm.stopRec(title); title = "" }) { Text(t("Stop & save", "إيقاف وحفظ")) }
        }
        Spacer(Modifier.height(16.dp))
        Text(t("Keep the app open while recording. Recordings stay on your phone.",
            "أبقِ التطبيق مفتوحا أثناء التسجيل. التسجيلات تبقى على هاتفك."), style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun SubjectsScreen(vm: AppVm, onGo: (Dest) -> Unit) {
    val subjects by vm.subjects.collectAsState()
    val lectures by vm.lectures.collectAsState()
    var adding by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Button(onClick = { adding = true }) { Text(t("New subject", "مادة جديدة")) }
        if (subjects.isEmpty()) Text(t("No subjects yet.", "لا توجد مواد بعد."))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(subjects, key = { it.id }) { s ->
                Card(onClick = { vm.subjectFilter = s.id; onGo(Dest.Lectures) }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(s.name, style = MaterialTheme.typography.titleMedium)
                            Text("${lectures.count { it.subjectId == s.id }} " + t("lectures", "محاضرات"), style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton(onClick = { vm.deleteSubject(s) }) { Text(t("Delete", "حذف")) }
                    }
                }
            }
        }
    }
    if (adding) AlertDialog(
        onDismissRequest = { adding = false },
        title = { Text(t("New subject", "مادة جديدة")) },
        text = { OutlinedTextField(name, { name = it }, singleLine = true) },
        confirmButton = { TextButton(onClick = { vm.addSubject(name); name = ""; adding = false }) { Text(t("Add", "إضافة")) } },
        dismissButton = { TextButton(onClick = { adding = false }) { Text(t("Cancel", "إلغاء")) } }
    )
}

@Composable
fun LecturePicker(vm: AppVm, onPick: (Long) -> Unit) {
    val lectures by vm.lectures.collectAsState()
    val subjects by vm.subjects.collectAsState()
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(t("Choose a lecture", "اختر محاضرة"), style = MaterialTheme.typography.titleSmall)
        if (lectures.isEmpty()) Text(t("No lectures yet.", "لا توجد محاضرات بعد."))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(lectures, key = { it.id }) { LectureRow(it, subjects, onPick) } }
    }
}

@Composable
fun AssistantScreen(vm: AppVm) {
    val lectures by vm.lectures.collectAsState()
    var sel by remember { mutableStateOf<Long?>(null) }
    val l = lectures.find { it.id == sel }
    if (l == null) LecturePicker(vm) { sel = it }
    else Column(Modifier.fillMaxSize()) {
        TextButton(onClick = { sel = null }) { Text("← " + l.title) }
        ChatPanel(vm, l)
    }
}

@Composable
fun ChatPanel(vm: AppVm, l: Lecture) {
    var input by remember { mutableStateOf("") }
    val msgs = vm.chats[l.id] ?: emptyList()
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text(t("Basic offline assistant: answers only with sentences found in this lecture's transcript.",
            "مساعد بسيط دون إنترنت: يجيب فقط بجمل موجودة في نص هذه المحاضرة."), style = MaterialTheme.typography.bodySmall)
        AssistChip(onClick = { vm.ask(l, "summarize") }, label = { Text(t("Summarize", "لخّص")) })
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(msgs) { m ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.user) Arrangement.End else Arrangement.Start) {
                    Card(colors = CardDefaults.cardColors(containerColor = if (m.user) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)) {
                        Text(m.text, Modifier.padding(10.dp))
                    }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), label = { Text(t("Ask about this lecture", "اسأل عن المحاضرة")) })
            Button(onClick = { if (input.isNotBlank()) { vm.ask(l, input); input = "" } }) { Text(t("Send", "إرسال")) }
        }
    }
}

@Composable
fun QuizzesScreen(vm: AppVm) {
    val lectures by vm.lectures.collectAsState()
    var sel by remember { mutableStateOf<Long?>(null) }
    val l = lectures.find { it.id == sel }
    if (l == null) LecturePicker(vm) { sel = it }
    else Column(Modifier.fillMaxSize()) {
        TextButton(onClick = { sel = null }) { Text("← " + l.title) }
        QuizPanel(vm, l)
    }
}

@Composable
fun QuizPanel(vm: AppVm, l: Lecture) {
    val qs by remember(l.id) { vm.questionsOf(l.id) }.collectAsState(initial = emptyList())
    var diff by remember { mutableIntStateOf(1) }
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(t("Easy", "سهل"), t("Medium", "متوسط"), t("Hard", "صعب")).forEachIndexed { i, n ->
                    FilterChip(selected = diff == i, onClick = { diff = i }, label = { Text(n) })
                }
            }
        }
        item {
            Button(onClick = { vm.generateQuiz(l, diff) }, enabled = l.transcript.isNotBlank()) { Text(t("Generate quiz", "إنشاء اختبار")) }
            if (l.transcript.isBlank()) Text(t("Add a transcript first (Transcript tab).", "أضف نصا للمحاضرة أولا (تبويب النص)."), style = MaterialTheme.typography.bodySmall)
        }
        items(qs, key = { it.id }) { QuestionCard(it) }
    }
}

@Composable
fun QuestionCard(q: QuizQuestion) {
    var picked by remember(q.id) { mutableStateOf<String?>(null) }
    var show by remember(q.id) { mutableStateOf(false) }
    val label = when (q.type) {
        "MCQ" -> t("Multiple choice", "اختيار من متعدد")
        "TF" -> t("True or false", "صح أو خطأ")
        "FILL" -> t("Complete the sentence", "أكمل الجملة")
        else -> t("Short answer", "إجابة قصيرة")
    }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium)
            Text(q.question)
            if (q.options.isNotBlank()) {
                q.options.split("|").forEach { opt ->
                    val mark = if (picked != null && opt == q.answer) "✓ " else if (picked == opt) "✗ " else ""
                    OutlinedButton(onClick = { picked = opt }, modifier = Modifier.fillMaxWidth()) { Text(mark + opt) }
                }
                if (picked != null) Text(q.explanation, style = MaterialTheme.typography.bodySmall)
            } else {
                TextButton(onClick = { show = !show }) { Text(t("Show answer", "إظهار الإجابة")) }
                if (show) Text(q.answer, color = MaterialTheme.colorScheme.tertiary)
            }
        }
    }
}

@Composable
fun FlashcardsScreen(vm: AppVm) {
    val cards by vm.cards.collectAsState()
    val lectures by vm.lectures.collectAsState()
    val subjects by vm.subjects.collectAsState()
    var idx by remember { mutableIntStateOf(0) }
    var flipped by remember { mutableStateOf(false) }
    var onlyNew by remember { mutableStateOf(false) }
    var subj by remember { mutableStateOf<Long?>(null) }
    val deck = cards.filter { c ->
        val lec = lectures.find { it.id == c.lectureId }
        (subj == null || lec?.subjectId == subj) && (!onlyNew || !c.reviewed)
    }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            item { FilterChip(selected = subj == null, onClick = { subj = null; idx = 0 }, label = { Text(t("All", "الكل")) }) }
            items(subjects, key = { it.id }) { s -> FilterChip(selected = subj == s.id, onClick = { subj = s.id; idx = 0 }, label = { Text(s.name) }) }
        }
        FilterChip(selected = onlyNew, onClick = { onlyNew = !onlyNew; idx = 0 }, label = { Text(t("Not reviewed only", "غير المراجعة فقط")) })
        Text(t("Reviewed", "تمت مراجعتها") + ": ${cards.count { it.reviewed }}/${cards.size}", style = MaterialTheme.typography.bodySmall)
        if (deck.isEmpty()) {
            Text(t("No flashcards. Open a lecture, add a transcript, then use the Cards tab.", "لا توجد بطاقات. افتح محاضرة وأضف نصا ثم استخدم تبويب البطاقات."))
        } else {
            val i = idx.coerceIn(0, deck.lastIndex)
            val c = deck[i]
            Card(onClick = { flipped = !flipped }, modifier = Modifier.fillMaxWidth().weight(1f)) {
                Box(Modifier.fillMaxSize().padding(20.dp), contentAlignment = Alignment.Center) {
                    Text(if (flipped) c.answer else c.question, style = MaterialTheme.typography.titleMedium)
                }
            }
            Text("${i + 1} / ${deck.size}  •  " + t("Tap card to flip", "اضغط لقلب البطاقة"))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { idx = (i - 1).coerceAtLeast(0); flipped = false }) { Text(t("Prev", "السابق")) }
                Button(onClick = { vm.markCard(c, true); idx = (i + 1).coerceAtMost(deck.lastIndex); flipped = false }) { Text(t("Got it", "عرفتها")) }
                OutlinedButton(onClick = { idx = (i + 1).coerceAtMost(deck.lastIndex); flipped = false }) { Text(t("Next", "التالي")) }
            }
        }
    }
}

@Composable
fun LectureDetail(vm: AppVm, id: Long, onBack: () -> Unit) {
    val lec by remember(id) { vm.lecture(id) }.collectAsState(initial = null)
    val subjects by vm.subjects.collectAsState()
    val l = lec
    if (l == null) { Text("…", Modifier.padding(16.dp)); return }
    var tab by remember { mutableIntStateOf(0) }
    var renaming by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }
    var newTitle by remember(l.title) { mutableStateOf(l.title) }
    var playing by remember { mutableStateOf(false) }
    val holder = remember { arrayOfNulls<MediaPlayer>(1) }
    DisposableEffect(Unit) { onDispose { holder[0]?.release() } }
    val tabs = listOf(t("Transcript", "النص"), t("Notes", "الملاحظات"), t("Chat", "المحادثة"), t("Quiz", "اختبار"), t("Cards", "البطاقات"), t("Export", "تصدير"))
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onBack) { Text("←") }
                Text(l.title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                TextButton(onClick = { renaming = true }) { Text(t("Rename", "تسمية")) }
                TextButton(onClick = { deleting = true }) { Text(t("Delete", "حذف")) }
            }
            val path = l.audioPath
            if (path != null) {
                TextButton(onClick = {
                    if (playing) { holder[0]?.release(); holder[0] = null; playing = false }
                    else try {
                        val p = MediaPlayer()
                        p.setDataSource(path); p.prepare()
                        p.setOnCompletionListener { playing = false; it.release(); holder[0] = null }
                        p.start(); holder[0] = p; playing = true
                    } catch (e: Exception) { playing = false }
                }) { Text((if (playing) t("Stop audio", "إيقاف الصوت") else t("Play audio", "تشغيل الصوت")) + "  (" + fmt(l.durationMs) + ")") }
            }
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                item { FilterChip(selected = l.subjectId == null, onClick = { vm.updateLecture(l.copy(subjectId = null)) }, label = { Text(t("No subject", "بدون مادة")) }) }
                items(subjects, key = { it.id }) { s ->
                    FilterChip(selected = l.subjectId == s.id, onClick = { vm.updateLecture(l.copy(subjectId = s.id)) }, label = { Text(s.name) })
                }
            }
        }
        ScrollableTabRow(selectedTabIndex = tab) {
            tabs.forEachIndexed { i, n -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(n) }) }
        }
        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> TranscriptTab(vm, l)
                1 -> NotesTab(vm, l)
                2 -> ChatPanel(vm, l)
                3 -> QuizPanel(vm, l)
                4 -> CardsTab(vm, l)
                else -> ExportTab(vm, l)
            }
        }
    }
    if (renaming) AlertDialog(
        onDismissRequest = { renaming = false },
        title = { Text(t("Rename lecture", "تسمية المحاضرة")) },
        text = { OutlinedTextField(newTitle, { newTitle = it }, singleLine = true) },
        confirmButton = { TextButton(onClick = { if (newTitle.isNotBlank()) vm.updateLecture(l.copy(title = newTitle.trim())); renaming = false }) { Text("OK") } },
        dismissButton = { TextButton(onClick = { renaming = false }) { Text(t("Cancel", "إلغاء")) } }
    )
    if (deleting) AlertDialog(
        onDismissRequest = { deleting = false },
        title = { Text(t("Delete this lecture and its recording?", "حذف المحاضرة وتسجيلها؟")) },
        confirmButton = { TextButton(onClick = { deleting = false; vm.deleteLecture(l); onBack() }) { Text(t("Delete", "حذف")) } },
        dismissButton = { TextButton(onClick = { deleting = false }) { Text(t("Cancel", "إلغاء")) } }
    )
}

@Composable
fun TranscriptTab(vm: AppVm, l: Lecture) {
    var text by remember(l.id) { mutableStateOf(l.transcript) }
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(t("Automatic speech-to-text is not in this build yet. Type, paste or edit the transcript here; all study features work from this text.",
            "تحويل الكلام إلى نص تلقائيا غير متوفر في هذا الإصدار بعد. اكتب أو الصق النص هنا؛ كل ميزات الدراسة تعمل من هذا النص."), style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth().weight(1f))
        Button(onClick = { vm.updateLecture(l.copy(transcript = text)) }) { Text(t("Save transcript", "حفظ النص")) }
    }
}

@Composable
fun NotesTab(vm: AppVm, l: Lecture) {
    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(t("Basic offline notes: picks the most representative sentences, terms, definitions and examples from the transcript.",
            "ملاحظات بسيطة دون إنترنت: تختار أهم الجمل والمصطلحات والتعريفات والأمثلة من النص."), style = MaterialTheme.typography.bodySmall)
        Button(onClick = { vm.generateNotes(l) }, enabled = l.transcript.isNotBlank()) { Text(t("Generate notes", "إنشاء الملاحظات")) }
        if (l.transcript.isBlank()) Text(t("Add a transcript first.", "أضف نصا أولا."))
        Text(l.summary)
    }
}

@Composable
fun CardsTab(vm: AppVm, l: Lecture) {
    val cards by remember(l.id) { vm.cardsOf(l.id) }.collectAsState(initial = emptyList())
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Button(onClick = { vm.generateCards(l) }, enabled = l.transcript.isNotBlank()) { Text(t("Generate flashcards", "إنشاء بطاقات")) } }
        items(cards, key = { it.id }) { c ->
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) { Text(c.question); Text(c.answer, color = MaterialTheme.colorScheme.tertiary) } }
        }
    }
}

@Composable
fun ExportTab(vm: AppVm, l: Lecture) {
    var kind by remember { mutableIntStateOf(0) }
    val pdf = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri -> if (uri != null) vm.export(l, kind, true, uri) }
    val docx = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) { uri -> if (uri != null) vm.export(l, kind, false, uri) }
    val names = listOf(t("Transcript", "النص"), t("Summary & key points", "الملخص والنقاط"), t("Quiz", "الاختبار"), t("Flashcards", "البطاقات"))
    val base = l.title.replace(Regex("[^\\p{L}\\p{N} _-]"), "_")
    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        names.forEachIndexed { i, n -> FilterChip(selected = kind == i, onClick = { kind = i }, label = { Text(n) }) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { pdf.launch("$base.pdf") }) { Text("PDF") }
            Button(onClick = { docx.launch("$base.docx") }) { Text("Word (DOCX)") }
        }
    }
}

@Composable
fun SettingsScreen(vm: AppVm, dark: Int, onDark: (Int) -> Unit, lang: String, onLang: (String) -> Unit) {
    var wipe by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(t("Language", "اللغة"), style = MaterialTheme.typography.titleSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = lang == "", onClick = { onLang("") }, label = { Text(t("System", "النظام")) })
            FilterChip(selected = lang == "en", onClick = { onLang("en") }, label = { Text("English") })
            FilterChip(selected = lang == "ar", onClick = { onLang("ar") }, label = { Text("العربية") })
        }
        Text(t("Theme", "المظهر"), style = MaterialTheme.typography.titleSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = dark == 0, onClick = { onDark(0) }, label = { Text(t("System", "النظام")) })
            FilterChip(selected = dark == 1, onClick = { onDark(1) }, label = { Text(t("Light", "فاتح")) })
            FilterChip(selected = dark == 2, onClick = { onDark(2) }, label = { Text(t("Dark", "داكن")) })
        }
        Text(t("Privacy", "الخصوصية"), style = MaterialTheme.typography.titleSmall)
        Text(t("Recordings and notes are stored only on this phone. Nothing is uploaded.", "التسجيلات والملاحظات محفوظة على هذا الهاتف فقط. لا يتم رفع أي شيء."))
        Text(t("AI status", "حالة الذكاء الاصطناعي"), style = MaterialTheme.typography.titleSmall)
        Text(t("Summaries, quizzes, flashcards and chat are basic offline text analysis, not a large language model. Automatic transcription is not available yet.",
            "الملخصات والاختبارات والبطاقات والمحادثة هي تحليل نصي بسيط دون إنترنت وليست نموذجا لغويا كبيرا. النسخ التلقائي للصوت غير متوفر بعد."))
        Button(onClick = { wipe = true }) { Text(t("Delete all my data", "حذف كل بياناتي")) }
    }
    if (wipe) AlertDialog(
        onDismissRequest = { wipe = false },
        title = { Text(t("Delete all lectures, recordings, cards and quizzes?", "حذف كل المحاضرات والتسجيلات والبطاقات والاختبارات؟")) },
        confirmButton = { TextButton(onClick = { vm.wipeAll(); wipe = false }) { Text(t("Delete", "حذف")) } },
        dismissButton = { TextButton(onClick = { wipe = false }) { Text(t("Cancel", "إلغاء")) } }
    )
}
